import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Clock, CheckCircle, XCircle, AlertTriangle } from 'lucide-react';
import { useBloodData } from '@/hooks/useBloodData';
import { toast } from "sonner";

const Requests = () => {
  const { requests, addRequest, updateRequestStatus, bloodInventory } = useBloodData();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [newRequest, setNewRequest] = useState({
    hospital: '',
    bloodType: '',
    units: '',
    priority: 'normal' as 'urgent' | 'high' | 'normal' | 'low',
    contact: '',
    notes: ''
  });

  const handleAddRequest = () => {
    if (!newRequest.hospital || !newRequest.bloodType || !newRequest.units) {
      toast.error("Please fill in all required fields");
      return;
    }

    const availableUnits = bloodInventory[newRequest.bloodType] || 0;
    const requestedUnits = parseInt(newRequest.units);

    addRequest({
      ...newRequest,
      id: Date.now().toString(),
      status: availableUnits >= requestedUnits ? 'pending' : 'insufficient',
      requestDate: new Date().toLocaleDateString(),
      timeAgo: 'Just now'
    });

    toast.success("Request submitted successfully!");
    setIsDialogOpen(false);
    setNewRequest({
      hospital: '',
      bloodType: '',
      units: '',
      priority: 'normal',
      contact: '',
      notes: ''
    });
  };

  const handleStatusUpdate = (requestId: string, newStatus: 'pending' | 'fulfilled' | 'rejected' | 'insufficient') => {
    updateRequestStatus(requestId, newStatus);
    toast.success(`Request status updated to ${newStatus}`);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'fulfilled': return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'rejected': return <XCircle className="h-4 w-4 text-red-600" />;
      case 'pending': return <Clock className="h-4 w-4 text-yellow-600" />;
      case 'insufficient': return <AlertTriangle className="h-4 w-4 text-orange-600" />;
      default: return <Clock className="h-4 w-4 text-gray-600" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'fulfilled': return 'bg-green-100 text-green-800';
      case 'rejected': return 'bg-red-100 text-red-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'insufficient': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'bg-red-500 text-white';
      case 'high': return 'bg-orange-500 text-white';
      case 'normal': return 'bg-blue-500 text-white';
      case 'low': return 'bg-gray-500 text-white';
      default: return 'bg-blue-500 text-white';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>Blood Requests Management</CardTitle>
              <CardDescription>
                Handle blood requests from hospitals and medical facilities
              </CardDescription>
            </div>
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-green-500 hover:bg-green-600">
                  <Plus className="h-4 w-4 mr-2" />
                  New Request
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[525px]">
                <DialogHeader>
                  <DialogTitle>Create Blood Request</DialogTitle>
                  <DialogDescription>
                    Submit a new blood request from a medical facility
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="hospital" className="text-right">
                      Hospital *
                    </Label>
                    <Input
                      id="hospital"
                      value={newRequest.hospital}
                      onChange={(e) => setNewRequest({ ...newRequest, hospital: e.target.value })}
                      className="col-span-3"
                      placeholder="Hospital name"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="bloodType" className="text-right">
                      Blood Type *
                    </Label>
                    <Select onValueChange={(value) => setNewRequest({ ...newRequest, bloodType: value })}>
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="Select blood type" />
                      </SelectTrigger>
                      <SelectContent>
                        {['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map((type) => (
                          <SelectItem key={type} value={type}>{type}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="units" className="text-right">
                      Units *
                    </Label>
                    <Input
                      id="units"
                      type="number"
                      value={newRequest.units}
                      onChange={(e) => setNewRequest({ ...newRequest, units: e.target.value })}
                      className="col-span-3"
                      placeholder="Number of units"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="priority" className="text-right">
                      Priority
                    </Label>
                    <Select onValueChange={(value: 'urgent' | 'high' | 'normal' | 'low') => setNewRequest({ ...newRequest, priority: value })} defaultValue="normal">
                      <SelectTrigger className="col-span-3">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="urgent">Urgent</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="normal">Normal</SelectItem>
                        <SelectItem value="low">Low</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="contact" className="text-right">
                      Contact
                    </Label>
                    <Input
                      id="contact"
                      value={newRequest.contact}
                      onChange={(e) => setNewRequest({ ...newRequest, contact: e.target.value })}
                      className="col-span-3"
                      placeholder="Contact information"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="notes" className="text-right">
                      Notes
                    </Label>
                    <Textarea
                      id="notes"
                      value={newRequest.notes}
                      onChange={(e) => setNewRequest({ ...newRequest, notes: e.target.value })}
                      className="col-span-3"
                      placeholder="Additional notes or patient information"
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button onClick={handleAddRequest} className="bg-green-500 hover:bg-green-600">
                    Submit Request
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
      </Card>

      {/* Requests Table */}
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Hospital</TableHead>
                <TableHead>Blood Type</TableHead>
                <TableHead>Units</TableHead>
                <TableHead>Priority</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Request Date</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {requests.map((request) => (
                <TableRow key={request.id}>
                  <TableCell className="font-medium">{request.hospital}</TableCell>
                  <TableCell>
                    <Badge variant="outline" className="font-mono">
                      {request.bloodType}
                    </Badge>
                  </TableCell>
                  <TableCell>{request.units}</TableCell>
                  <TableCell>
                    <Badge className={getPriorityColor(request.priority)}>
                      {request.priority}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      {getStatusIcon(request.status)}
                      <Badge className={getStatusColor(request.status)}>
                        {request.status}
                      </Badge>
                    </div>
                  </TableCell>
                  <TableCell>{request.requestDate}</TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      {request.status === 'pending' && (
                        <>
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => handleStatusUpdate(request.id, 'fulfilled')}
                            className="bg-green-50 hover:bg-green-100"
                          >
                            Fulfill
                          </Button>
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => handleStatusUpdate(request.id, 'rejected')}
                            className="bg-red-50 hover:bg-red-100"
                          >
                            Reject
                          </Button>
                        </>
                      )}
                      {request.status === 'insufficient' && (
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleStatusUpdate(request.id, 'pending')}
                          className="bg-orange-50 hover:bg-orange-100"
                        >
                          Retry
                        </Button>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Pending Requests</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">
              {requests.filter(req => req.status === 'pending').length}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Fulfilled Today</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {requests.filter(req => req.status === 'fulfilled').length}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Urgent Requests</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              {requests.filter(req => req.priority === 'urgent' && req.status === 'pending').length}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Insufficient Stock</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">
              {requests.filter(req => req.status === 'insufficient').length}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Requests;
