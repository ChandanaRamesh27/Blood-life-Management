import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell
} from 'recharts';
import { TrendingUp, Users, Droplets, Calendar } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useBloodData } from '@/hooks/useBloodData';

const Analytics = () => {
  const { bloodInventory, donors, requests } = useBloodData();

  const donationTrends = [
    { month: 'Jan', donations: 45 },
    { month: 'Feb', donations: 52 },
    { month: 'Mar', donations: 48 },
    { month: 'Apr', donations: 61 },
    { month: 'May', donations: 55 },
    { month: 'Jun', donations: 67 }
  ];

  const bloodTypeDistribution = Object.entries(bloodInventory).map(([type, units]) => ({
    name: type,
    value: units
  }));

  const requestTrends = [
    { month: 'Jan', requests: 38, fulfilled: 35 },
    { month: 'Feb', requests: 42, fulfilled: 39 },
    { month: 'Mar', requests: 39, fulfilled: 36 },
    { month: 'Apr', requests: 48, fulfilled: 44 },
    { month: 'May', requests: 51, fulfilled: 47 },
    { month: 'Jun', requests: 55, fulfilled: 52 }
  ];

  const COLORS = ['#dc2626', '#ea580c', '#ca8a04', '#65a30d', '#059669', '#0891b2', '#2563eb', '#7c3aed'];

  return (
    <div className="max-w-screen-2xl mx-auto px-4 pb-10 space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <CardTitle>Analytics & Reports</CardTitle>
          <CardDescription>
            Comprehensive insights into blood bank operations and trends
          </CardDescription>
        </CardHeader>
      </Card>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Monthly Growth</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">+12.5%</div>
            <p className="text-xs text-muted-foreground">Donations vs last month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Average Age</CardTitle>
            <Users className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">28.4</div>
            <p className="text-xs text-muted-foreground">Years (donor average)</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Collection Rate</CardTitle>
            <Droplets className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">94.2%</div>
            <p className="text-xs text-muted-foreground">Successful collections</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Response Time</CardTitle>
            <Calendar className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">2.3h</div>
            <p className="text-xs text-muted-foreground">Average request fulfillment</p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Monthly Donation Trends</CardTitle>
            <CardDescription>Blood donations over the past 6 months</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={donationTrends}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Line
                  type="monotone"
                  dataKey="donations"
                  stroke="#dc2626"
                  strokeWidth={3}
                  dot={{ fill: '#dc2626', strokeWidth: 2, r: 4 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Blood Type Distribution</CardTitle>
            <CardDescription>Current inventory by blood type</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={bloodTypeDistribution}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {bloodTypeDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Request Fulfillment Rate</CardTitle>
            <CardDescription>Blood requests vs successful fulfillments</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={requestTrends}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="requests" fill="#ef4444" name="Requests" />
                <Bar dataKey="fulfilled" fill="#22c55e" name="Fulfilled" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Blood Type Inventory Levels</CardTitle>
            <CardDescription>Current stock levels by blood type</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={bloodTypeDistribution}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="value" fill="#3b82f6" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Summary Report */}
      

      {/* Embedded Looker Studio Report */}
      <Card>
        <CardHeader>
          <CardTitle>External Report (Looker Studio)</CardTitle>
          <CardDescription>
            Embedded analytics from Google Looker Studio
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="relative w-full overflow-hidden rounded-lg aspect-[16/9]">
            <iframe
              title="Looker Studio Report"
              src="https://lookerstudio.google.com/embed/reporting/600b6831-da3e-47ba-81bf-cc0997f213a4/page/tEnnC"
              className="w-full h-full border-0"
              allowFullScreen
              sandbox="allow-storage-access-by-user-activation allow-scripts allow-same-origin allow-popups allow-popups-to-escape-sandbox"
            ></iframe>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Monthly Summary Report</CardTitle>
          <CardDescription>Key performance indicators for June 2024</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <h4 className="font-semibold text-green-700">Achievements</h4>
              <ul className="text-sm space-y-1 text-green-600">
                <li>• 12.5% increase in donations</li>
                <li>• 94.2% collection success rate</li>
                <li>• 15 new donor registrations</li>
                <li>• Zero critical shortages</li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold text-yellow-700">Areas for Improvement</h4>
              <ul className="text-sm space-y-1 text-yellow-600">
                <li>• AB- blood type low stock</li>
                <li>• Response time above target</li>
                <li>• Need more O+ donors</li>
                <li>• Weekend staffing gaps</li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold text-blue-700">Upcoming Goals</h4>
              <ul className="text-sm space-y-1 text-blue-600">
                <li>• Target 75 donations in July</li>
                <li>• Reduce response time to &lt;2h</li>
                <li>• Launch mobile drive program</li>
                <li>• Implement donor app</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Analytics;
