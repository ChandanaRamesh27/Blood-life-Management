import { useEffect, useState } from 'react';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

interface Donor {
  id?: string; // ✅ optional now
  name: string;
  bloodType: string;
  phone?: string;
  lastDonation?: string;
  status?: string;
  totalDonations?: number;
}

const DonorForm = () => {
  const { toast } = useToast();

  const [form, setForm] = useState<Donor>({
    name: '',
    bloodType: '',
    phone: '',
    lastDonation: '',
    status: ''
  });


  const [donors, setDonors] = useState<Donor[]>([]);

 const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
  const { name, value } = e.target;
  setForm(prev => ({
    ...prev,
    [name]: value
  }));
};


  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!form.name || !form.bloodType) {
      toast({ title: "Error", description: "Name and blood type are required", variant: "destructive" });
      return;
    }

    const today = new Date().toISOString().split('T')[0];
    const donorToSend = {
      ...form,
      lastDonation: form.lastDonation || today // ✅ fallback to today
    };

    try {
      const res = await fetch("http://localhost:3000/api/donors", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(donorToSend),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to add donor");

      toast({ title: "Success", description: "Donor added successfully" });

      setForm({
        name: '',
        bloodType: '',
        phone: '',
        lastDonation: '',
        status: ''
      });

      fetchDonors();
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  };

  const fetchDonors = async () => {
    try {
      const res = await fetch("http://localhost:3000/api/donors");
      const data = await res.json();
      setDonors(data);
    } catch (error) {
      toast({ title: "Error", description: "Failed to fetch donors", variant: "destructive" });
    }
  };

  const handleDeleteDonor = async (id: string) => {
    if (!confirm(`Are you sure you want to delete this donor?`)) return;

    try {
      const res = await fetch(`http://localhost:3000/api/donors/${id}`, {
        method: "DELETE"
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to delete donor");

      toast({ title: "Deleted", description: "Donor deleted successfully" });
      fetchDonors();
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  };

  useEffect(() => {
    fetchDonors();
  }, []);

  return (
    <div className="max-w-3xl mx-auto p-6 space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Add Donor</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="name">Name</Label>
              <Input id="name" name="name" value={form.name} onChange={handleChange} required />
            </div>
            <div>
              <Label htmlFor="bloodType">Blood Type</Label>
              <Input id="bloodType" name="bloodType" value={form.bloodType} onChange={handleChange} required />
            </div>
            <div>
              <Label htmlFor="phone">Phone</Label>
              <Input id="phone" name="phone" value={form.phone} onChange={handleChange} />
            </div>
            <div>
              <Label htmlFor="lastDonation">Last Donation Date</Label>
              <Input id="lastDonation" name="lastDonation" type="date" value={form.lastDonation} onChange={handleChange} />
            </div>
            <div>
              <Label htmlFor="status">Status</Label>
              <Input id="status" name="status" value={form.status} onChange={handleChange} />
            </div>
            
            <Button type="submit" className="w-full bg-red-600 hover:bg-red-700 text-white">Add Donor</Button>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Donor List</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            {donors.map((donor, index) => (
              <li key={index} className="border-b pb-2 flex justify-between items-center">
                <div>
                  <strong>{donor.name}</strong> — {donor.bloodType}
                  {donor.status && <span> ({donor.status})</span>}
                  {donor.lastDonation && (
                    <span className="ml-2 text-sm text-blue-600">
                      • Last: {new Date(donor.lastDonation).toLocaleDateString()}
                    </span>
                  )}
                  {typeof donor.totalDonations === 'number' && (
                    <span className="ml-2 text-sm text-gray-500">
                      • Donations: {donor.totalDonations}
                    </span>
                  )}
                </div>
                <Button
                  size="sm"
                  variant="destructive"
                  onClick={() => handleDeleteDonor(donor.id!)}
                >
                  Delete
                </Button>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
    </div>
  );
};

export default DonorForm;
