
import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { Plus, Minus, AlertTriangle, Package } from 'lucide-react';
import { useBloodData } from '@/hooks/useBloodData';
import { toast } from "sonner";

const Inventory = () => {
  const { bloodInventory, updateInventory } = useBloodData();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedType, setSelectedType] = useState('');
  const [action, setAction] = useState('add');
  const [units, setUnits] = useState('');

  const bloodTypes = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

  const getStockLevel = (units: number) => {
    if (units < 10) return 'critical';
    if (units < 25) return 'low';
    return 'normal';
  };

  const getStockColor = (level: string) => {
    switch (level) {
      case 'critical': return 'destructive';
      case 'low': return 'secondary';
      default: return 'default';
    }
  };

  const getProgressColor = (level: string) => {
    switch (level) {
      case 'critical': return 'bg-red-500';
      case 'low': return 'bg-yellow-500';
      default: return 'bg-green-500';
    }
  };

  const handleInventoryUpdate = () => {
    if (!selectedType || !units) {
      toast.error("Please select blood type and enter units");
      return;
    }

    const currentUnits = bloodInventory[selectedType] || 0;
    const changeUnits = parseInt(units);
    const newUnits = action === 'add' ? currentUnits + changeUnits : Math.max(0, currentUnits - changeUnits);

    updateInventory(selectedType, newUnits);
    
    toast.success(`Successfully ${action === 'add' ? 'added' : 'removed'} ${units} units of ${selectedType}`);
    setIsDialogOpen(false);
    setSelectedType('');
    setUnits('');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>Blood Inventory Management</CardTitle>
              <CardDescription>
                Monitor and manage blood unit inventory levels
              </CardDescription>
            </div>
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              {/* <DialogTrigger asChild>
                <Button className="bg-blue-500 hover:bg-blue-600">
                  <Package className="h-4 w-4 mr-2" />
                  Update Inventory
                </Button>
              </DialogTrigger> */}
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Update Blood Inventory</DialogTitle>
                  <DialogDescription>
                    Add or remove blood units from inventory
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="bloodType" className="text-right">
                      Blood Type
                    </Label>
                    <Select onValueChange={setSelectedType}>
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="Select blood type" />
                      </SelectTrigger>
                      <SelectContent>
                        {bloodTypes.map((type) => (
                          <SelectItem key={type} value={type}>{type}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="action" className="text-right">
                      Action
                    </Label>
                    <Select onValueChange={setAction} defaultValue="add">
                      <SelectTrigger className="col-span-3">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="add">Add Units</SelectItem>
                        <SelectItem value="remove">Remove Units</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="units" className="text-right">
                      Units
                    </Label>
                    <Input
                      id="units"
                      type="number"
                      value={units}
                      onChange={(e) => setUnits(e.target.value)}
                      className="col-span-3"
                      placeholder="Enter number of units"
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button onClick={handleInventoryUpdate} className="bg-blue-500 hover:bg-blue-600">
                    Update Inventory
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
      </Card>

      {/* Inventory Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {bloodTypes.map((type) => {
          const units = bloodInventory[type] || 0;
          const level = getStockLevel(units);
          const percentage = Math.min((units / 100) * 100, 100);
          
          return (
            <Card key={type} className={`relative overflow-hidden ${level === 'critical' ? 'border-red-200 bg-red-50' : level === 'low' ? 'border-yellow-200 bg-yellow-50' : 'border-green-200 bg-green-50'}`}>
              <CardHeader className="pb-3">
                <div className="flex justify-between items-center">
                  <CardTitle className="text-2xl font-bold">{type}</CardTitle>
                  <Badge variant={getStockColor(level)} className="capitalize">
                    {level}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center">
                  <div className="text-3xl font-bold text-gray-900">{units}</div>
                  <div className="text-sm text-gray-600">Units Available</div>
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Stock Level</span>
                    <span>{percentage.toFixed(0)}%</span>
                  </div>
                  <Progress value={percentage} className="h-2" />
                </div>

                {level === 'critical' && (
                  <div className="flex items-center space-x-2 p-2 bg-red-100 rounded-lg">
                    <AlertTriangle className="h-4 w-4 text-red-600" />
                    <span className="text-xs text-red-700">Critical Level!</span>
                  </div>
                )}

                <div className="flex space-x-2">
                  <Button 
                    size="sm" 
                    variant="outline" 
                    className="flex-1"
                    onClick={() => {
                      setSelectedType(type);
                      setAction('add');
                      setIsDialogOpen(true);
                    }}
                  >
                    <Plus className="h-3 w-3 mr-1" />
                    Add
                  </Button>
                  <Button 
                    size="sm" 
                    variant="outline" 
                    className="flex-1"
                    onClick={() => {
                      setSelectedType(type);
                      setAction('remove');
                      setIsDialogOpen(true);
                    }}
                  >
                    <Minus className="h-3 w-3 mr-1" />
                    Remove
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Total Units</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-600">
              {Object.values(bloodInventory).reduce((sum, units) => sum + units, 0)}
            </div>
            <p className="text-sm text-gray-600">Across all blood types</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Critical Types</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-red-600">
              {bloodTypes.filter(type => getStockLevel(bloodInventory[type] || 0) === 'critical').length}
            </div>
            <p className="text-sm text-gray-600">Requiring immediate attention</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Well Stocked</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">
              {bloodTypes.filter(type => getStockLevel(bloodInventory[type] || 0) === 'normal').length}
            </div>
            <p className="text-sm text-gray-600">Adequate supply levels</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Inventory;
