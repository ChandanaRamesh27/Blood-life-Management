import { useEffect, useState } from 'react';

import {
  Card, CardContent, CardDescription, CardHeader, CardTitle,
} from "@/components/ui/card";

import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow
} from "@/components/ui/table";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from "@/components/ui/select";

import { Badge } from "@/components/ui/badge";

import {
  Dialog, DialogContent, DialogDescription, DialogFooter,
  DialogHeader, DialogTitle, DialogTrigger
} from "@/components/ui/dialog";

import { Plus, Search, Edit, Calendar, Trash } from 'lucide-react';
import { toast } from "sonner";

interface Donor {
  id?: string;
  name: string;
  email: string;
  phone: string;
  bloodType: string;
  age?: string;
  address?: string;
  lastDonation?: string;
  status: 'eligible' | 'deferred' | 'inactive';
  totalDonations?: number;
  registrationDate?: string;
}

const DonorManagement = () => {
  const [donors, setDonors] = useState<Donor[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editDonorId, setEditDonorId] = useState<string | null>(null);
  const [newDonor, setNewDonor] = useState<Donor>({
    name: '',
    email: '',
    phone: '',
    bloodType: '',
    age: '',
    address: '',
    lastDonation: '',
    status: 'eligible',
    totalDonations: 0
  });

  // Fetch donors from backend
  const fetchDonors = async () => {
    try {
      const res = await fetch("http://localhost:3000/api/donors");
      const data = await res.json();
      setDonors(data);
    } catch (err) {
      toast.error("Failed to fetch donors");
    }
  };

  useEffect(() => {
    fetchDonors();
  }, []);

  // Add or update donor
  const handleAddDonor = async () => {
  if (!newDonor.name || !newDonor.bloodType || !newDonor.phone) {
    toast.error("Please fill in all required fields");
    return;
  }

  try {
    const method = editDonorId ? "PUT" : "POST";
    const url = editDonorId
      ? `http://localhost:3000/api/donors/${editDonorId}`
      : "http://localhost:3000/api/donors";

    const res = await fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ...newDonor,
        totalDonations: editDonorId ? newDonor.totalDonations : 1
      })
    });

    const data = await res.json();

    if (!res.ok) throw new Error(data.error || "Failed");

    toast.success(editDonorId ? "Donor updated" : "Donor added");

    setIsAddDialogOpen(false);
    setEditDonorId(null);
    setNewDonor({
      name: '',
      email: '',
      phone: '',
      bloodType: '',
      age: '',
      address: '',
      lastDonation: '',
      status: 'eligible',
      totalDonations: 0
    });

    fetchDonors();
  } catch (err: any) {
    toast.error(err.message);
  }
};


  //END

  // Delete donor
  const handleDeleteDonor = async (id: string) => {
    if (!confirm("Are you sure you want to delete this donor?")) return;

    try {
      const res = await fetch(`http://localhost:3000/api/donors/${id}`, {
        method: "DELETE"
      });
      if (!res.ok) throw new Error("Failed to delete");

      toast.success("Donor Deleted Successfully!");
      fetchDonors();
    } catch (err) {
      toast.error("Failed to delete donor");
    }
  };

  const filteredDonors = donors.filter((donor) =>
    donor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    donor.bloodType.includes(searchTerm.toUpperCase())
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'eligible': return 'bg-green-100 text-green-800';
      case 'deferred': return 'bg-yellow-100 text-yellow-800';
      case 'inactive': return 'bg-gray-100 text-gray-800';
      default: return 'bg-blue-100 text-blue-800';
    }
  };

  // Increment total donations
const handleIncrementDonation = async (id: string) => {
  try {
    const res = await fetch(`http://localhost:3000/api/donors/${id}/increment-donations`, {
      method: "PUT",
    });

    if (!res.ok) throw new Error("Failed to increment donation");

    const updatedDonor = await res.json();

    // Update the donor in the state
    setDonors((prev) =>
      prev.map((d) => (d.id === updatedDonor._id ? { ...d, totalDonations: updatedDonor.totalDonations } : d))
    );

    toast.success("Donation count incremented!");
  } catch (err) {
    toast.error("Error incrementing donation");
  }
};


  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>Donor Management</CardTitle>
              <CardDescription>Manage blood donors and their information</CardDescription>
            </div>
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-red-500 hover:bg-red-600">
                  <Plus className="h-4 w-4 mr-2" />
                  Add New Donor
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>{editDonorId ? "Edit Donor" : "Add New Donor"}</DialogTitle>
                  <DialogDescription>Fill the donor information below.</DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="name" className="text-right">Name *</Label>
                      <Input
                        id="name"
                        value={newDonor.name}
                        onChange={(e) => {
                          const value = e.target.value;
                          // Allow only letters and spaces
                          if (/^[A-Za-z\s]*$/.test(value)) {
                            setNewDonor({ ...newDonor, name: value });
                          }
                        }}
                        className="col-span-3"
                      />
                    </div>

                      {/* Address */}
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="address" className="text-right">Address</Label>
                      <Input
                        id="address"
                        value={newDonor.address}
                        onChange={(e) => setNewDonor({ ...newDonor, address: e.target.value })}
                        className="col-span-3"
                      />
                    </div>

                    {/* Last Donation Date */}
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="lastDonation" className="text-right">Last Donation</Label>
                      <Input
                        id="lastDonation"
                        type="date"
                        value={newDonor.lastDonation}
                        onChange={(e) => setNewDonor({ ...newDonor, lastDonation: e.target.value })}
                        className="col-span-3"
                      />
                    </div>


                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="bloodType" className="text-right">Blood Type *</Label>
                    <Select
                      onValueChange={(value) => setNewDonor({ ...newDonor, bloodType: value })}
                      value={newDonor.bloodType}
                    >
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="Select blood type" />
                      </SelectTrigger>
                      <SelectContent>
                        {['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map(type => (
                          <SelectItem key={type} value={type}>{type}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                   <Label htmlFor="phone" className="text-right">Phone *</Label>
                    <Input
                      id="phone"
                      value={newDonor.phone}
                      onChange={(e) => {
                        const value = e.target.value;
                        // Allow only digits
                        if (/^\d*$/.test(value)) {
                          setNewDonor({ ...newDonor, phone: value });
                        }
                      }}
                      className="col-span-3"
                      maxLength={10} // Optional: limit to 10 digits
                    />
                  </div>

                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="email" className="text-right">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={newDonor.email}
                      onChange={(e) => setNewDonor({ ...newDonor, email: e.target.value })}
                      className="col-span-3"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="age" className="text-right">Age</Label>
                    <Input
                      id="age"
                      type="number"
                      value={newDonor.age}
                      onChange={(e) => setNewDonor({ ...newDonor, age: e.target.value })}
                      className="col-span-3"
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button onClick={handleAddDonor} className="bg-red-500 hover:bg-red-600">
                    {editDonorId ? "Update Donor" : "Add Donor"}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-2">
            <Search className="h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search donors by name or blood type..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="max-w-sm"
            />
          </div>
        </CardContent>
      </Card>

      {/* Donor Table */}
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Blood Type</TableHead>
                <TableHead>Phone</TableHead>
                <TableHead>Last Donation</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Total Donations</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredDonors.map((donor) => (
                <TableRow key={donor.id}>
                  <TableCell>{donor.name}</TableCell>
                  <TableCell>
                    <Badge variant="outline" className="font-mono">{donor.bloodType}</Badge>
                  </TableCell>
                  <TableCell>{donor.phone}</TableCell>
                  <TableCell>
  {donor.lastDonation
    ? new Date(donor.lastDonation).toLocaleDateString()
    : 'Never'}
</TableCell>

                  <TableCell>
                    <Badge className={getStatusColor(donor.status)}>{donor.status}</Badge>
                  </TableCell>
                  <TableCell>{donor.totalDonations || 0}</TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <Button variant="outline" size="sm" onClick={() => {
                        setNewDonor(donor);
                        setEditDonorId(donor.id || null);
                        setIsAddDialogOpen(true);
                      }}>
                        <Edit className="h-3 w-3" />
                      </Button>
                      <Button variant="outline" size="sm">
                        <Calendar className="h-3 w-3" />
                      </Button>
                      <Button variant="destructive" size="sm" onClick={() => handleDeleteDonor(donor.id!)}>
                        <Trash className="h-3 w-3" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default DonorManagement;
