
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Heart, Users, Droplets, AlertTriangle, TrendingUp, Calendar } from 'lucide-react';
import { useBloodData } from '@/hooks/useBloodData';

const Dashboard = () => {
  const { bloodInventory, donors, requests, stats } = useBloodData();

  const bloodTypes = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
  
  const getStockLevel = (units: number) => {
    if (units < 10) return 'critical';
    if (units < 25) return 'low';
    return 'normal';
  };

  const getStockColor = (level: string) => {
    switch (level) {
      case 'critical': return 'bg-red-500';
      case 'low': return 'bg-yellow-500';
      default: return 'bg-green-500';
    }
  };

  return (
    <div className="space-y-6">
      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-gradient-to-r from-red-500 to-red-600 text-white border-0">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Blood Units</CardTitle>
            <Droplets className="h-4 w-4" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalUnits}</div>
            <p className="text-xs text-red-100">
              +{stats.unitsThisMonth} this month
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white border-0">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Donors</CardTitle>
            <Users className="h-4 w-4" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.activeDonors}</div>
            <p className="text-xs text-blue-100">
              +{stats.newDonorsThisMonth} new this month
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white border-0">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Requests Fulfilled</CardTitle>
            <Heart className="h-4 w-4" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.requestsFulfilled}</div>
            <p className="text-xs text-green-100">
              {stats.fulfillmentRate}% success rate
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white border-0">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Lives Saved</CardTitle>
            <TrendingUp className="h-4 w-4" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.livesSaved}</div>
            <p className="text-xs text-purple-100">
              Estimated impact
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Blood Inventory Grid */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Droplets className="h-5 w-5 text-red-500" />
            <span>Blood Inventory Status</span>
          </CardTitle>
          <CardDescription>
            Real-time blood units availability by type
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {bloodTypes.map((type) => {
              const units = bloodInventory[type] || 0;
              const level = getStockLevel(units);
              const percentage = Math.min((units / 50) * 100, 100);
              
              return (
                <div key={type} className="space-y-3 p-4 border rounded-lg bg-white hover:shadow-md transition-shadow">
                  <div className="flex justify-between items-center">
                    <span className="font-semibold text-lg">{type}</span>
                    <Badge 
                      variant={level === 'critical' ? 'destructive' : level === 'low' ? 'secondary' : 'default'}
                      className={level === 'normal' ? 'bg-green-100 text-green-800' : ''}
                    >
                      {level}
                    </Badge>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Units: {units}</span>
                      <span>{percentage.toFixed(0)}%</span>
                    </div>
                    <Progress value={percentage} className="h-2" />
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Calendar className="h-5 w-5 text-blue-500" />
              <span>Recent Donations</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {donors.slice(0, 5).map((donor, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div>
                  <p className="font-medium">{donor.name}</p>
                  <p className="text-sm text-gray-600">Type {donor.bloodType}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium">{donor.lastDonation}</p>
                  <Badge variant="outline" className="text-xs">
                    {donor.status}
                  </Badge>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <AlertTriangle className="h-5 w-5 text-orange-500" />
              <span>Urgent Requests</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {requests.filter(req => req.priority === 'urgent').slice(0, 5).map((request, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-red-50 rounded-lg border border-red-100">
                <div>
                  <p className="font-medium">{request.hospital}</p>
                  <p className="text-sm text-gray-600">Type {request.bloodType} - {request.units} units</p>
                </div>
                <div className="text-right">
                  <Badge variant="destructive">
                    {request.priority}
                  </Badge>
                  <p className="text-xs text-gray-500 mt-1">{request.timeAgo}</p>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;
