import { useState, useEffect } from 'react';

// Types
interface Donor {
  id: string;
  name: string;
  email: string;
  phone: string;
  bloodType: string;
  age: string;
  address: string;
  lastDonation: string;
  status: 'eligible' | 'deferred' | 'inactive';
  registrationDate: string;
  totalDonations: number;
}

interface Request {
  id: string;
  hospital: string;
  bloodType: string;
  units: string;
  priority: 'urgent' | 'high' | 'normal' | 'low';
  status: 'pending' | 'fulfilled' | 'rejected' | 'insufficient';
  contact: string;
  notes: string;
  requestDate: string;
  timeAgo: string;
}

interface BloodInventory {
  [key: string]: number;
}

interface Stats {
  totalUnits: number;
  unitsThisMonth: number;
  activeDonors: number;
  newDonorsThisMonth: number;
  requestsFulfilled: number;
  fulfillmentRate: number;
  livesSaved: number;
}

// Initial sample stats only
const initialStats: Stats = {
  totalUnits: 221,
  unitsThisMonth: 47,
  activeDonors: 156,
  newDonorsThisMonth: 12,
  requestsFulfilled: 89,
  fulfillmentRate: 94,
  livesSaved: 267,
};

export const useBloodData = () => {
  const [bloodInventory, setBloodInventory] = useState<BloodInventory>({});
  const [donors, setDonors] = useState<Donor[]>([]);
  const [requests, setRequests] = useState<Request[]>([]);
  const [stats, setStats] = useState<Stats>(initialStats);

  // ✅ Fetch inventory and requests on mount
  useEffect(() => {
    fetchInventory();
    fetchRequests();
  }, []);

  // ✅ Add this here:
  const recomputeStats = () => {
    const totalUnits = Object.values(bloodInventory).reduce((sum, u) => sum + u, 0);
    const activeDonors = donors.filter(d => d.status === 'eligible').length;
    const newDonorsThisMonth = donors.filter(d => {
      const now = new Date();
      const registered = new Date(d.registrationDate);
      return registered.getMonth() === now.getMonth() && registered.getFullYear() === now.getFullYear();
    }).length;
    const fulfilled = requests.filter(r => r.status === 'fulfilled').length;
    const totalRequests = requests.length;
    const fulfillmentRate = totalRequests ? Math.round((fulfilled / totalRequests) * 100) : 0;
    const livesSaved = Math.round(fulfilled * 2.9);

    setStats({
      totalUnits,
      unitsThisMonth: totalUnits, // or compute separately if needed
      activeDonors,
      newDonorsThisMonth,
      requestsFulfilled: fulfilled,
      fulfillmentRate,
      livesSaved,
    });
  };

  // Inventory
  const fetchInventory = async () => {
    try {
      const res = await fetch("http://localhost:3000/api/inventory");
      const data = await res.json();
      setBloodInventory(data);
    } catch (error) {
      console.error("Failed to fetch inventory:", error);
    }
  };

  const updateInventory = async (bloodType: string, newUnits: number) => {
    try {
      const res = await fetch("http://localhost:3000/api/inventory", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ bloodType, units: newUnits }),
      });
      const updated = await res.json();
      setBloodInventory(prev => ({
        ...prev,
        [bloodType]: updated.inventory.units,
      }));
    } catch (error) {
      console.error("Error updating inventory:", error);
    }
  };

  // Requests
  const fetchRequests = async () => {
    try {
      const res = await fetch("http://localhost:3000/api/requests");
      const data = await res.json();
      setRequests(data);
    } catch (error) {
      console.error("Failed to fetch requests:", error);
    }
  };

  const addRequest = async (request: Request) => {
    try {
      const res = await fetch("http://localhost:3000/api/requests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(request),
      });
      const data = await res.json();
      setRequests(prev => [...prev, data.request]);
    } catch (error) {
      console.error("Failed to add request:", error);
    }
  };

  const updateRequestStatus = async (
    id: string,
    newStatus: 'pending' | 'fulfilled' | 'rejected' | 'insufficient'
  ) => {
    try {
      const res = await fetch(`http://localhost:3000/api/requests/${id}/status`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: newStatus }),
      });
      const updated = await res.json();
      setRequests(prev =>
        prev.map(r => (r.id === id ? { ...r, status: updated.request.status } : r))
      );
      if (newStatus === 'fulfilled') {
        setStats(prev => ({
          ...prev,
          requestsFulfilled: prev.requestsFulfilled + 1,
        }));
      }
    } catch (error) {
      console.error("Failed to update request status:", error);
    }
  };

  // LocalStorage syncing (for offline support)
  useEffect(() => {
    const savedDonors = localStorage.getItem('donors');
    const savedStats = localStorage.getItem('stats');
    if (savedDonors) setDonors(JSON.parse(savedDonors));
    if (savedStats) setStats(JSON.parse(savedStats));
  }, []);

  useEffect(() => {
    localStorage.setItem('donors', JSON.stringify(donors));
  }, [donors]);

  useEffect(() => {
    localStorage.setItem('requests', JSON.stringify(requests));
  }, [requests]);

  useEffect(() => {
    localStorage.setItem('stats', JSON.stringify(stats));
  }, [stats]);

  // ✅ Recompute stats whenever data changes
  useEffect(() => {
    recomputeStats();
  }, [bloodInventory, donors, requests]);

  // Donor management
  const addDonor = (donor: Donor) => {
    setDonors(prev => [...prev, donor]);
    setStats(prev => ({
      ...prev,
      activeDonors: prev.activeDonors + 1,
      newDonorsThisMonth: prev.newDonorsThisMonth + 1,
    }));
  };

  const updateDonor = (donorId: string, updates: Partial<Donor>) => {
    setDonors(prev =>
      prev.map(donor =>
        donor.id === donorId ? { ...donor, ...updates } : donor
      )
    );
  };

  const deleteDonor = (donorId: string) => {
    setDonors(prev => prev.filter(donor => donor.id !== donorId));
    setStats(prev => ({
      ...prev,
      activeDonors: Math.max(prev.activeDonors - 1, 0),
    }));
  };

  return {
    bloodInventory,
    donors,
    requests,
    stats,
    updateInventory,
    addDonor,
    updateDonor,
    deleteDonor,
    addRequest,
    updateRequestStatus,
  };
};
