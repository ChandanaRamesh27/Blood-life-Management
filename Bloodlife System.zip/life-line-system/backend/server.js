// server.js
import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import bcrypt from 'bcryptjs';
import bodyParser from 'body-parser';

const app = express();
const PORT = 3000;

// ✅ MongoDB Atlas URI
const MONGO_URI = 'mongodb+srv://chandanaramesh:Sgt205250@cluster0.ekkkwlm.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0';

// ✅ Connect to MongoDB Atlas
mongoose.connect(MONGO_URI)
  .then(() => console.log('✅ MongoDB Atlas connected successfully'))
  .catch((err) => console.error('❌ MongoDB connection error:', err.message));

app.use(cors());
app.use(bodyParser.json());
app.use(express.json());

// -------------------- USER SCHEMA & ROUTES --------------------
const userSchema = new mongoose.Schema({
  name: String,
  email: { type: String, unique: true },
  phone: String,
  password: String,
  role: { type: String, default: 'user' }
});

const User = mongoose.model('User', userSchema);

// ✅ Register Route
app.post('/api/register', async (req, res) => {
  const { name, email, phone, password } = req.body;

  if (!name || !email || !password) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  try {
    const existingUser = await User.findOne({ email });
    if (existingUser) return res.status(400).json({ error: 'Email already exists' });

    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = new User({ name, email, phone, password: hashedPassword });

    await newUser.save();

    res.status(201).json({
      message: 'User registered successfully',
      user: { name, email, role: 'user' }
    });
  } catch (err) {
    console.error('Error in registration:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ✅ Login Route
app.post('/api/login', async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password)
    return res.status(400).json({ error: 'Missing email or password' });

  try {
    const user = await User.findOne({ email });
    if (!user) return res.status(401).json({ error: 'Invalid credentials' });

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(401).json({ error: 'Invalid credentials' });

    res.json({
      message: 'Login successful',
      user: {
        name: user.name,
        email: user.email,
        role: user.role
      }
    });
  } catch (err) {
    console.error('Error in login:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// -------------------- DONOR SCHEMA & ROUTES --------------------
const donorSchema = new mongoose.Schema({
  name: { type: String, required: true },
  bloodType: { type: String, required: true },
  phone: String,
  lastDonation: String,
  status: String,
  totalDonations: { type: Number, default: 0 }
});

const Donor = mongoose.model('Donor', donorSchema);

// ✅ Add Donor with automatic totalDonations logic
app.post('/api/donors', async (req, res) => {
  try {
    console.log('Received Donor Data:', req.body);

    const { name, bloodType, phone, lastDonation, status } = req.body;

    if (!name || !bloodType) {
      return res.status(400).json({ error: 'Name and blood type are required' }); 
    }

    // Set totalDonations = 1 if lastDonation is provided, else 0
    const totalDonations = lastDonation ? 1 : 0;

    const newDonor = new Donor({
      name,
      bloodType,
      phone,
      lastDonation,
      status,
      totalDonations,
    });

    await newDonor.save();
    res.status(201).json({ message: 'Donor added successfully' });
  } catch (err) {
    console.error('Error adding donor:', err);
    res.status(500).json({ error: 'Server error' });
  }
});




// ✅ Get All Donors with `id` mapped
app.get('/api/donors', async (req, res) => {
  try {
    const donors = await Donor.find().sort({ name: 1 });
    const mapped = donors.map(d => ({ ...d.toObject(), id: d._id.toString() }));
    res.json(mapped);
  } catch (err) {
    console.error('Error fetching donors:', err);
    res.status(500).json({ error: 'Server error' });
  }
});


// ✅ Delete Donor
app.delete('/api/donors/:id', async (req, res) => {
  const { id } = req.params;

  try {
    const deleted = await Donor.findByIdAndDelete(id);
    if (!deleted) {
      return res.status(404).json({ error: 'Donor not found' });
    }
    res.json({ message: 'Donor deleted successfully' });
  } catch (err) {
    console.error('Error deleting donor:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ✅ Update Donor
app.put('/api/donors/:id', async (req, res) => {
  const { id } = req.params;
  const updateData = req.body;

  try {
    const updatedDonor = await Donor.findByIdAndUpdate(id, updateData, { new: true });

    if (!updatedDonor) {
      return res.status(404).json({ error: 'Donor not found' });
    }

    res.json({ message: 'Donor updated successfully', donor: updatedDonor });
  } catch (err) {
    console.error('Error updating donor:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// -------------------- REQUEST SCHEMA & ROUTES --------------------
const requestSchema = new mongoose.Schema({
  id: String,
  hospital: String,
  bloodType: String,
  units: String,
  priority: String,
  contact: String,
  notes: String,
  status: String,
  requestDate: String,
  timeAgo: String
});

const Request = mongoose.model('Request', requestSchema);

// ✅ Add New Request
app.post('/api/requests', async (req, res) => {
  try {
    const newRequest = new Request(req.body);
    await newRequest.save();
    res.status(201).json({ message: 'Request submitted successfully', request: newRequest });
  } catch (err) {
    console.error('Error submitting request:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ✅ Get All Requests
app.get('/api/requests', async (req, res) => {
  try {
    const requests = await Request.find();
    res.json(requests);
  } catch (err) {
    console.error('Error fetching requests:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ✅ Update Request Status
app.put('/api/requests/:id/status', async (req, res) => {
  const { id } = req.params;
  const { status } = req.body;

  try {
    const updated = await Request.findOneAndUpdate({ id }, { status }, { new: true });
    res.json({ message: 'Status updated', request: updated });
  } catch (err) {
    console.error('Error updating request status:', err);
    res.status(500).json({ error: 'Server error' });
  }
});


// -------------------- INVENTORY SCHEMA & ROUTES --------------------
const inventorySchema = new mongoose.Schema({
  bloodType: { type: String, required: true, unique: true },
  units: { type: Number, default: 0 },
});

const Inventory = mongoose.model('Inventory', inventorySchema);


// ✅ Get current inventory
app.get('/api/inventory', async (req, res) => {
  try {
    const data = await Inventory.find();
    const formatted = {};
    data.forEach(item => {
      formatted[item.bloodType] = item.units;
    });
    res.json(formatted);
  } catch (err) {
    console.error('Error fetching inventory:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ✅ Update blood units (add/remove)
app.put('/api/inventory', async (req, res) => {
  const { bloodType, units } = req.body;

  if (!bloodType || typeof units !== 'number') {
    return res.status(400).json({ error: 'Invalid input' });
  }

  try {
    const updated = await Inventory.findOneAndUpdate(
      { bloodType },
      { $set: { units } },
      { upsert: true, new: true }
    );
    res.json({ message: 'Inventory updated successfully', inventory: updated });
  } catch (err) {
    console.error('Error updating inventory:', err);
    res.status(500).json({ error: 'Server error' });
  }
});


// -------------------- ROOT ROUTE --------------------
app.get('/', (req, res) => {
  res.send('<h1>✅ Server is running!</h1><p>This is the backend for BloodLife.</p>');
});

// -------------------- START SERVER --------------------
app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});
